"""Priority 1: inventory + copy the pre-correction original game/stat CSVs (read-only on sources)."""
import csv, hashlib, os, shutil, datetime as dt, json, glob
W = "/workspace"; S = f"{W}/supplement_2026-11-10"; R = f"{S}/priority1_originals/recovered_originals"
os.makedirs(R, exist_ok=True)
def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""): h.update(b)
    return h.hexdigest()
def rows(p):
    with open(p, newline="") as f: return sum(1 for _ in csv.reader(f)) - 1
def mt(p): return dt.datetime.fromtimestamp(os.path.getmtime(p)).strftime("%Y-%m-%d %H:%M:%S ET")
RAWNOTE = ("built by lax_data/scripts/04_build_datasets.py from raw NCAA JSON on this box: "
           "scoreboards https://data.ncaa.com/casablanca/scoreboard/lacrosse-men/d1/YYYY/MM/DD/scoreboard.json "
           "(fetched 2026-11-10 10:43-10:49 ET, lax_data/raw/scoreboard_fetch_log.tsv), box scores and play-by-play "
           "from https://sdataprod.ncaa.com/ GameCenter persisted queries (fetched 10:47-11:30 ET, lax_data/raw/detail_fetch_log.tsv)")
ESPN = "; ESPN site-API scoreboards (lax_data/raw/espn_scoreboards, fetched 10:43-10:49 ET) used for espn_* cross-check columns (ESPN = restricted source)"
items = [
 ("ncaa_lacrosse_games_2023.csv", "games", RAWNOTE + ESPN, "corrected/ncaa_lacrosse_games_2023_corrected.csv"),
 ("ncaa_lacrosse_games_2024.csv", "games", RAWNOTE + ESPN, "corrected/ncaa_lacrosse_games_2024_corrected.csv"),
 ("ncaa_lacrosse_game_index_2025.csv", "games", RAWNOTE + ESPN, "corrected/ncaa_lacrosse_game_index_2025_corrected.csv"),
 ("ncaa_lacrosse_team_game_stats_2023_2025.csv", "team_stats", RAWNOTE + " (faceoffs/clears derived from play-by-play)", "corrected/ncaa_lacrosse_team_game_stats_2023_2025_corrected.csv"),
 ("ncaa_lacrosse_player_stats_2023_2025.csv", "player_stats", RAWNOTE, "corrected/ncaa_lacrosse_player_stats_2023_2025_corrected.csv"),
 ("odds_game_to_ncaa_game_crosswalk.csv", "crosswalk", "built by lax_data/scripts/07_odds_to_ncaa_crosswalk.py from the three games files above + the original 1,470-record odds file", "corrected/odds_game_to_ncaa_game_crosswalk_corrected.csv"),
]
out = []
for fn, kind, origin, corr in items:
    fp, lp = f"{W}/final_package/{fn}", f"{W}/lax_data/processed/{fn}"
    h = sha(fp); assert h == sha(lp), fn
    shutil.copy2(fp, f"{R}/{fn}")
    ch = sha(f"{W}/audit_package/{corr}")
    out.append(dict(original_filename=fn, dataset=kind, status="recovered (actual file, byte-identical copy)",
        box_paths=f"{fp} ; {lp} (identical)", included_in_zip="yes", origin=origin,
        collection_date=f"raw JSON fetched 2026-11-10 (ET); CSV built {mt(lp)} (lax_data/processed), copied to final_package {mt(fp)}",
        sha256=h, rows=rows(fp), file_type="intermediate built by our script from raw JSON (not an externally downloaded file)",
        relationship=f"pre-correction original of audit_package/{corr} (sha256 {ch}, rows {rows(f'{W}/audit_package/{corr}')}); listed in audit_package/validated_data_inventory.csv" + (" as in_package=False" if kind != "crosswalk" else " only via its corrected copy"),
        notes="Earliest persisted version. If 04/07 were run more than once before 11:42 ET, earlier outputs were overwritten and cannot be recovered (no log shows a re-run)."))
# additional odds (the sixth external file)
fn = "ncaa_lacrosse_additional_odds_2023_2026.csv"; fp = f"{W}/deliverables/{fn}"
assert sha(fp) == sha(f"{W}/final_package/{fn}")
shutil.copy2(fp, f"{R}/{fn}")
out.append(dict(original_filename=fn, dataset="odds_additional", status="recovered (actual file, byte-identical copy)",
    box_paths=f"{fp} ; {W}/final_package/{fn} (identical)", included_in_zip="yes",
    origin="built by deliverables/scripts/build_additional.py from parsed Wayback BetMGM pages (raw_new/mgm/mgm_rows.json), Wayback DraftKings nash API JSON, Lacrosse All Stars and LegalSportsBetting articles",
    collection_date=f"built {mt(fp)}", sha256=sha(fp), rows=rows(fp), file_type="intermediate built by our script from saved evidence",
    relationship="the 525 'additional' odds records (A0001-A0525) in audit_package/odds_provenance_audit.csv; listed in validated_data_inventory.csv as in_package=False",
    notes="Odds content quarantined (requires_permission); shared here only for private academic audit, as in the earlier data package."))
# original odds 1,470 (already in audit package) - listed for completeness, not copied again
fp = f"{W}/ncaa_lacrosse_historical_odds_2025.csv"
out.append(dict(original_filename="ncaa_lacrosse_historical_odds_2025.csv", dataset="odds_original", status="already delivered in audit_package/originals/ (not duplicated)",
    box_paths=fp, included_in_zip="no (already in ncaa_lacrosse_cse519_audit_package.zip)", origin="first-pass odds build (scripts/ in /workspace) from wb/, an/, an_wb/, bol/, lsb/",
    collection_date=f"built {mt(fp)}", sha256=sha(fp), rows=rows(fp), file_type="intermediate built by our script", relationship="records O0001-O1470 in odds_provenance_audit.csv", notes="unchanged"))
for fn, why in [("user's local 580-game 2025 CSV (dsf-project repo)", "never on this box; owned by the user; not available to us"),
                ("user's local 72 team-season records 2022-23 (dsf-project repo)", "never on this box; owned by the user; not available to us")]:
    out.append(dict(original_filename=fn, dataset="user_local", status="UNAVAILABLE to us", box_paths="", included_in_zip="no", origin="user's own repository",
        collection_date="unknown", sha256="", rows="", file_type="external", relationship="none: our datasets were collected independently and were never matched against it", notes=why))
# raw NCAA JSON: hash list only
rawrows = []
for sub in ["scoreboards", "boxscores", "pbp", "espn_scoreboards", "sidearm"]:
    for p in sorted(glob.glob(f"{W}/lax_data/raw/{sub}/**/*", recursive=True)):
        if os.path.isfile(p):
            rawrows.append(dict(path=p.replace(W + "/", ""), bytes=os.path.getsize(p), sha256=sha(p), mtime_et=mt(p),
                publisher={"espn_scoreboards": "ESPN (restricted)", "sidearm": "school athletics site (uncertain)"}.get(sub, "NCAA (uncertain)"), included_in_zip="no (hash only)"))
for p in sorted(glob.glob(f"{W}/lax_data/raw/*")):
    if os.path.isfile(p): shutil.copy2(p, f"{S}/priority1_originals/raw_fetch_logs/" + os.path.basename(p)) if os.makedirs(f"{S}/priority1_originals/raw_fetch_logs", exist_ok=True) is None else None
shutil.copy2(f"{W}/lax_data/processed/build_log.json", f"{S}/priority1_originals/raw_fetch_logs/build_log.json")
shutil.copy2(f"{W}/lax_data/processed/excluded_or_flagged_duplicate_listings.csv", f"{R}/excluded_or_flagged_duplicate_listings.csv")
out.append(dict(original_filename="excluded_or_flagged_duplicate_listings.csv", dataset="games", status="recovered (actual file)", box_paths=f"{W}/lax_data/processed/excluded_or_flagged_duplicate_listings.csv",
    included_in_zip="yes", origin="written by 04_build_datasets.py", collection_date=mt(f"{W}/lax_data/processed/excluded_or_flagged_duplicate_listings.csv"),
    sha256=sha(f"{R}/excluded_or_flagged_duplicate_listings.csv"), rows=rows(f"{R}/excluded_or_flagged_duplicate_listings.csv"), file_type="build side output",
    relationship="duplicate NCAA listings removed before the games originals were written", notes=""))
with open(f"{S}/priority1_originals/original_files_inventory.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(out[0])); w.writeheader(); w.writerows(out)
with open(f"{S}/priority1_originals/raw_ncaa_json_sha256.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(rawrows[0])); w.writeheader(); w.writerows(rawrows)
print(len(out), "inventory rows;", len(rawrows), "raw files hashed;", sum(r['bytes'] for r in rawrows)/1e6, "MB")
