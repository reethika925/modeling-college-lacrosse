# Source permissions report (CSE 519 NCAA D-I men's lacrosse)

Prepared 2026-11-10 for Kiran Reddy Bhumireddy (Stony Brook CSE 519, Prof. Steven Skiena). The machine-readable version is `permissions_matrix.csv`.

**How to read this.** Each source has three uses:
- **Internal academic analysis:** using the facts privately, inside the course project.
- **Automated collection:** scripted fetching.
- **Redistribution:** sharing copies or datasets outside the project team.

Quotes come from terms pages saved on 2026-11-10. Most were saved at 11:55–11:57 AM ET; their files are in `audit_package/evidence/odds/raw_terms/`. The BetMGM New Jersey and Massachusetts terms were saved at 4:51 PM ET and are in `terms_retrieved_2026-11-10/`. "Unresolved" means the text does not settle the question, so a lawyer or the source would have to decide. This is not legal advice.

## Summary

| Source | Internal academic analysis | Automated collection | Redistribution | Status |
|---|---|---|---|---|
| NCAA.com and its data endpoints | unresolved (factual results) | unresolved (no explicit ban found) | restricted without permission | uncertain |
| Official school sites (SIDEARM) | unresolved ("personal use") | allowed by robots.txt; terms silent, so unresolved | restricted | uncertain |
| Action Network | restricted | prohibited | prohibited without written permission | restricted |
| DraftKings | restricted ("personal use only") | prohibited (whether this covers Wayback copies is unresolved) | prohibited without consent | restricted |
| BetMGM | restricted/unresolved | unresolved | restricted | uncertain, treated as restricted |
| Bet On Lacrosse | unresolved (no terms exist) | unresolved (robots.txt allows everything) | unresolved ("All rights reserved") | uncertain |
| Lacrosse All Stars | unresolved (terms page is a 404) | unresolved | unresolved | uncertain |
| LegalSportsBetting | unresolved (no terms found) | unresolved | unresolved | uncertain |
| Internet Archive | permitted for research | permitted at the Archive level | no rights in captured content | depends on the captured site |
| ESPN (Disney) | restricted | prohibited | prohibited | restricted |
| The Odds API | permitted | permitted with an API key | no standalone redistribution | cleared by its terms (you have already contacted them) |

## Per source

### NCAA.com, data.ncaa.com and sdataprod.ncaa.com
- **What we used it for:** the primary source for all games, team stats and player stats.
- **Terms** (https://www.ncaa.com/tos): "You may not modify, reproduce, publish, transmit, participate in the transfer or sale, create derivative works, use for commercial purposes, or in any way exploit, any of the NCAA Content, in whole or in part except as provided in these Terms of Service." They also say: "Except as otherwise expressly permitted under United States copyright law, no copying, redistribution, retransmission, publication, or commercial exploitation of downloaded material will be permitted without the express permission".
- **Internal academic analysis:** unresolved. Game results are facts, and the terms carve out what US copyright law allows. Private academic use is plausible, but the terms do not say so.
- **Automated collection:** unresolved. The saved terms contain no robots or scraping clause. ncaa.com's robots.txt does not disallow scoreboard pages, and data.ncaa.com has no robots.txt (404). stats.ncaa.org returned 403 and was not used.
- **Redistribution:** restricted without NCAA permission.

### Official school athletics sites (SIDEARM platform)
- **What we used them for:** checking dates and scores only. They are not a data source.
- **Terms** (https://sidearmsports.com/terms-of-service): "Copying or storing of any Content for other than personal use is expressly prohibited without prior written permission".
- **Internal academic analysis:** unresolved.
- **Automated collection:** robots.txt was checked before each fetch, and the 30 s crawl delay was honoured (31 s). The terms are silent on robots, so this is unresolved.
- **Redistribution:** restricted. The school pages that are already in the audit package are for internal verification only.

### Action Network (832 odds records: 824 from live pages, 8 from Wayback)
- **Terms** (https://www.actionnetwork.com/terms):
  - "You may browse this Site and all associated content solely for your personal use and enjoyment."
  - "Except for downloading one copy of the Materials on any single computer for your personal, non-commercial home use, you must not reproduce, modify, copy, publish, transmit, prepare derivative works based upon, distribute, perform or display the Materials without first obtaining the written permission…"
  - "You may not use any “deep-link”, “page-scrape”, “robot”, “spider” or other automatic device, program, algorithm or methodology, or any similar or equivalent manual process, to access, acquire, copy or monitor any portion of the Site".
- **All three uses** are restricted or prohibited without written permission.

### DraftKings (412 odds records, all from Internet Archive captures; DraftKings itself was never accessed)
- **Terms** (https://myaccount.draftkings.com/documents/us-terms-of-use):
  - "Using automated means (including but not limited to harvesting bots, robots, parser, spiders or screen scrapers) to obtain, collect or access any information on the Website or of any User for any purpose."
  - "Content on the Website is provided to you AS IS for your information and personal use only and may not be used, copied, reproduced, distributed, transmitted, broadcast, displayed, sold, licensed, or otherwise exploited for any other purposes whatsoever without the prior written consent…"
- **Internal academic analysis:** restricted.
- **Automated collection:** prohibited on the site. Whether the clause reaches archive copies is unresolved.
- **Redistribution:** prohibited without consent.

### BetMGM (292 odds records, all from Internet Archive captures)
- **Terms:** the New Jersey account-holder terms of service (https://help.nj.betmgm.com/en/general-information/legal-matters/general-terms-and-conditions, "Last Updated September 16, 2026") say:
  - §7.9: use of the Services "is for Your personal, entertainment use on Your personal computer, mobile device or similar electronic device only. You may not use the Services or any intellectual property contained therein for any commercial purpose."
  - §26 "NO REPRODUCTION OR RESALE": "You agree not to reproduce, duplicate, copy, sell, resell or exploit for any commercial purposes, any portion of the Platforms…"
  - §8: "You obtain no rights in such copyright material … and must not use them without the Affiliate Group’s written permission."
  - The Massachusetts terms have the same §26 wording.
- **Internal academic analysis:** restricted or unresolved. These are account-holder terms, and §26 is framed around commercial exploitation.
- **Automated collection:** unresolved. These terms ban wagering "BOT"s, but I found no scraping clause. BetMGM's Nevada app terms ban "any robot, scraper, spider", but that is a different operator, seen in search results only and not saved.
- **Redistribution:** restricted.

### Bet On Lacrosse (428 odds records)
- **Terms:** none exist. /terms-of-service/ and /terms-and-conditions/ return 404. The footer reads "Bet On Lacrosse Copyright 2026 · All rights reserved". The homepage invites readers to "research historical betting data for free using the Bet On Lacrosse Report". robots.txt is "User-agent: * Disallow:", which allows everything.
- **All three uses** are unresolved. Prices are facts, but the site reserves all rights and grants no license.

### Lacrosse All Stars (25 odds records)
- **Terms:** the terms link in the footer (https://laxallstars.com/articles/terms-of-use) returns "Page Not Found". robots.txt allows everything except /api/ and /_projects/.
- **All three uses** are unresolved.

### LegalSportsBetting.com (6 odds records, all grade C)
- **Terms:** none found (the terms URLs return 404). robots.txt allows /news/.
- **All three uses** are unresolved. The article does not name a sportsbook, so these records stay grade C whatever the permission outcome.

### Internet Archive (the access route for 878 odds records)
- **Terms:** from the 2020 Wayback copy of https://archive.org/about/terms.php, because the live page is rendered by JavaScript:
  - "Access to the Archive’s Collections is provided at no cost to you and is granted for scholarship and research purposes only."
  - "you certify that your use of any part of the Archive's Collections will be limited to noninfringing or fair use under copyright law."
- **Internal academic analysis:** permitted as far as the Archive is concerned.
- **Automated collection:** permitted at the Archive level. robots.txt disallows only /control/ and /report/.
- **Redistribution:** the Archive grants no rights in captured content, so each capture still falls under the captured site's terms (DraftKings, BetMGM, Action Network, Bet On Lacrosse).
- **Unresolved:** whether the current live terms differ from the 2020 copy.

### ESPN / Disney (no odds records; used for game cross-checks and the espn_* columns)
- **Terms** (https://disneytermsofuse.com/english/): Disney grants a license "for your personal, noncommercial use only". It bars accessing or copying "using a robot, spider, script, or other automated means, including … for the purposes of … data mining or web scraping or otherwise compiling, building, creating or contributing to any collection of data, data set or database".
- **All three uses** are restricted or prohibited.
- **Recommendation:** remove the ESPN-derived columns, and the one row that only ESPN reports, rather than asking Disney for permission.

### The Odds API
- **Terms** (https://the-odds-api.com/terms-and-conditions.html): they permit "Using our data in research papers and analytical dashboards" and storing data indefinitely. They also say "Do not resell, repackage, or redistribute our data as a standalone data product."
- **Status:** cleared by its terms. No records came from it, because historical odds need a paid plan and no purchase was made. You have already contacted The Odds API about academic access, so no email is drafted and no further step is suggested here.

## What clears data for analysis
- **Odds:** all 1,983 non-rejected records stay quarantined until both of these hold:
  - the publisher named in each record's `permission_class` grants permission;
  - for the 878 Wayback-sourced records, the captured sportsbook grants permission (the Internet Archive alone is not enough).
- **Games and stats:**
  - written NCAA permission settles redistribution;
  - you and Prof. Skiena signing off settles internal analysis;
  - the ESPN-derived columns should be removed.
