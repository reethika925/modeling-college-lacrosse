# Permission-request email drafts (NOT SENT)

These are drafts only, and nothing has been sent. Each body is 150 words or fewer. Send any of them only after you have reviewed it. No draft is included for The Odds API, because you have already contacted them. No draft is included for ESPN either; removing the ESPN-derived columns is the recommended fix. The Internet Archive does not need a request, because the permission that matters comes from the captured sites.

Contact addresses are given only where one appeared in a page saved on 2026-11-10. Where none did, the draft says "contact address not found".

---

## 1. Action Network
**To:** contact address not found. The only address in https://www.actionnetwork.com/terms is the DMCA agent, feedback@actionnetwork.com (subject "DMCA Request"), which is not a licensing contact. Use a general or partnerships contact if you can find one.
**Subject:** Permission request: academic use of archived NCAA lacrosse odds from Action Network articles

Hello,

I am a graduate student in CSE 519 at Stony Brook University, supervised by Prof. Steven Skiena. Our course project models NCAA Division I men's lacrosse. We recorded the betting lines printed in Action Network's 2023–2024 college lacrosse preview articles (sportsbook, market, line and price only) to evaluate forecast calibration.

We are asking for written permission to use these facts for internal, non-commercial academic analysis. We will not redistribute your articles or a dataset of your lines, and we will cite Action Network in our report. Until we hear from you, the records are quarantined and unused.

May we have your permission? If not, we will delete them.

Thank you,
Kiran Reddy Bhumireddy
Graduate Student, Stony Brook University (CSE 519, Prof. Steven Skiena)

---

## 2. DraftKings
**To:** contact address not found. The terms list support@draftkings.com, but only for transaction-fee reimbursement.
**Subject:** Academic permission request: archived DraftKings NCAA lacrosse lines (Internet Archive copies)

Hello,

I am a graduate student in Stony Brook University's CSE 519 course (Prof. Steven Skiena). For a course project on NCAA Division I men's lacrosse, we found Internet Archive captures of DraftKings' public NCAA lacrosse pages from 2023–2026. We did not access DraftKings directly.

We are asking for written consent to use the lines and prices shown in those captures for internal, non-commercial academic analysis of forecast accuracy. We will not redistribute DraftKings content or the dataset, and we will credit DraftKings. Until consent is given, the records are quarantined.

Could you grant permission, or point us to the right team?

Thank you,
Kiran Reddy Bhumireddy
Graduate Student, Stony Brook University (CSE 519, Prof. Steven Skiena)

---

## 3. BetMGM
**To:** contact address not found for licensing. The NJ terms (§28.3.3) list LegalDepartment@betmgm.com as the address for legal notices and disputes; it may be able to redirect the request.
**Subject:** Academic permission request: archived BetMGM NCAA lacrosse odds

Hello,

I am a graduate student in CSE 519 at Stony Brook University, supervised by Prof. Steven Skiena. For a course project on NCAA Division I men's lacrosse, we used Internet Archive captures (2024–2025) of BetMGM's public lacrosse pages and noted the spreads, totals and moneylines shown.

We are asking for written permission to use these facts for internal, non-commercial academic analysis only. We will not reproduce your pages, redistribute the data, or use it commercially, and we will credit BetMGM. Until permission is given, the records are quarantined.

Could you grant permission or forward this to the appropriate team?

Thank you,
Kiran Reddy Bhumireddy
Graduate Student, Stony Brook University (CSE 519, Prof. Steven Skiena)

---

## 4. Bet On Lacrosse (Hutton Jackson)
**To:** contact address not found in the saved pages. The site links to Instagram, X and YouTube, and its newsletter signup is another route.
**Subject:** Permission to use Bet On Lacrosse NCAA odds for a Stony Brook class project

Hi Hutton,

I am a graduate student in Stony Brook University's CSE 519 course (Prof. Steven Skiena). For our project on NCAA Division I men's lacrosse, we recorded the sportsbook lines quoted in your 2025 college lacrosse betting previews (book, market, line, price) to test how well odds predict results.

May we use these facts for internal, non-commercial academic analysis? We will not republish your articles or share the dataset, and we will credit Bet On Lacrosse. We would also welcome guidance on using the Bet On Lacrosse Report. Until we hear back, the records are set aside.

Thank you,
Kiran Reddy Bhumireddy
Graduate Student, Stony Brook University (CSE 519, Prof. Steven Skiena)

---

## 5. Lacrosse All Stars
**To:** editorial@laxallstars.com. This is a mailto address on laxallstars.com pages saved 2026-11-10 (raw_terms/tos_laxallstars.html and tos_laxallstars2.html).
**Subject:** Permission request: academic use of odds quoted in LAS college lacrosse betting columns

Hello,

I am a graduate student in CSE 519 at Stony Brook University (Prof. Steven Skiena). For our course project on NCAA Division I men's lacrosse, we noted 25 betting lines quoted in Lacrosse All Stars' 2023–2024 college best-bets columns.

Your terms-of-use link currently returns "Page Not Found", so we are asking directly. May we use these facts for internal, non-commercial academic analysis? We will not republish your articles or redistribute the data, and we will cite Lacrosse All Stars. Until then, the records are quarantined.

Thank you,
Kiran Reddy Bhumireddy
Graduate Student, Stony Brook University (CSE 519, Prof. Steven Skiena)

---

## 6. LegalSportsBetting.com
**To:** contact form at https://www.legalsportsbetting.com/contact/ (linked from the saved article page). No email address was found.
**Subject:** Academic permission request: NCAA lacrosse odds in a 2026 article

Hello,

I am a graduate student in Stony Brook University's CSE 519 course (Prof. Steven Skiena). Our project models NCAA Division I men's lacrosse. We recorded the odds printed in your April 2026 article "Bet College Lacrosse: History Puts #2 Notre Dame Over #1 UNC".

May we use those facts for internal, non-commercial academic analysis? We will not republish the article or redistribute the data, and we will cite LegalSportsBetting.com. It would also help to know which sportsbook the odds came from.

Thank you,
Kiran Reddy Bhumireddy
Graduate Student, Stony Brook University (CSE 519, Prof. Steven Skiena)

---

## 7. NCAA (NCAA.com / NCAA statistics)
**To:** contact address not found for data licensing. The NCAA.com terms list only legal-notice and copyright-agent addresses (notice@wbd.com, TSIcopyrightagent@turner.com), which are not data-permission contacts. Consider asking through Stony Brook's library or the NCAA's media and statistics office.
**Subject:** Academic use of NCAA.com men's lacrosse results and box scores (Stony Brook CSE 519)

Hello,

I am a graduate student in CSE 519 at Stony Brook University, supervised by Prof. Steven Skiena. For a course project on NCAA Division I men's lacrosse, we compiled 2023–2025 game results, box-score team stats and player stats from NCAA.com's public scoreboard and game pages.

We are asking for permission to use these facts for internal, non-commercial academic analysis. We will share them only with our instructor and course staff, will not publish or redistribute the dataset, and will credit NCAA.com.

Is this acceptable, or is there a preferred route for academic access?

Thank you,
Kiran Reddy Bhumireddy
Graduate Student, Stony Brook University (CSE 519, Prof. Steven Skiena)
