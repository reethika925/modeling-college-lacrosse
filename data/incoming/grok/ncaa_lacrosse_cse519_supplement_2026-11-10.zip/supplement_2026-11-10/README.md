# Supplement, 2026-11-10: recovered originals, odds evidence, permissions, references

This is a supplement to `ncaa_lacrosse_cse519_audit_package.zip` and `ncaa_lacrosse_cse519_data_package.zip`, which are unchanged. It contains no new data collection, no re-run of the earlier audit checks, and no models. Start with `supplement_report.md`.

To check the package, run `python3 verify_supplement.py` from this folder. It needs Python 3 only, and confirms that every file's sha256, byte count and CSV row count match `MANIFEST.csv`.

| Folder / file | What it is |
|---|---|
| `supplement_report.md` | Findings, counts, what was recovered, what is still missing, remaining limitations |
| `priority1_originals/original_files_inventory.csv` | One row per original file: filename, box path, origin, collection date, sha256, rows, relationship to the corrected dataset |
| `priority1_originals/recovered_originals/` | The actual pre-correction files (byte-identical copies): games 2023, games 2024, game index 2025, team game stats, player stats, odds crosswalk, the 525 additional odds records, and the duplicate-listing side file |
| `priority1_originals/original_vs_corrected_*.csv` | Cell-level diff of each original against its corrected copy in the audit package (value changes vs format-only changes) |
| `priority1_originals/raw_ncaa_json_sha256.csv` | sha256 of all 4,223 raw NCAA/ESPN/school JSON and HTML files used by the build scripts (hash only; content not included) |
| `priority1_originals/raw_fetch_logs/` | Fetch logs with timestamps for the raw JSON, plus the build log |
| `priority2_odds_evidence/odds_evidence_inventory.csv` | All 294 saved odds-evidence files: path, type, publisher, permission class, source URL, Wayback timestamp/URL, save time, bytes, sha256, records supported, included_in_zip |
| `priority2_odds_evidence/odds_evidence_to_record_map.csv` | All 1,995 odds records (O0001–O1470, A0001–A0525) mapped to evidence file, sha256, URLs, quote/capture/article timestamps, evidence excerpt, grade, status and verification route |
| `priority2_odds_evidence/odds_evidence_counts.json` | Counts by status, publisher, grade, timestamp availability and verification route |
| `priority2_odds_evidence/included_metadata/` | The 36 shareable evidence files: our own URL lists, parsed extractions and Internet Archive CDX index listings, at their original relative paths |
| `priority2_odds_evidence/source_url_lists/` | Source URL lists: first-pass `sources_used.txt`, the audit-package URL list, live URL status, and the 93 evidence source URLs with record IDs |
| `priority3_permissions/permissions_report.md`, `permissions_matrix.csv` | Source-by-source terms for internal academic analysis, automated collection and redistribution |
| `priority3_permissions/permission_request_emails.md` | 7 draft emails, NOT SENT |
| `priority3_permissions/terms_retrieved_2026-11-10/` | The BetMGM NJ and MA terms saved 2026-11-10 at 4:51 PM ET (the other terms files are already in the audit package) |
| `priority4_references/references.md` | 8 verified references plus 2 alternates; `crossref_records/` holds the raw Crossref responses |
| `scripts/` | The scripts that built this supplement (s1–s4) |
| `MANIFEST.csv`, `verify_supplement.py` | Manifest and integrity check |

**Inclusion rule for third-party material.** No third-party odds page or data capture is in this zip. The only third-party pages included are the two public BetMGM terms-of-service documents, kept so their quoted wording can be checked, as the audit package did for the other terms pages. That covers DraftKings, Action Network and ESPN (restricted), and BetMGM, Bet On Lacrosse, Lacrosse All Stars, LegalSportsBetting, Pinnacle, NCAA and school pages (uncertain). Their terms either forbid reproduction or grant no license, and the uncertain ones remain under the project's quarantine rule until permission is confirmed. Each withheld file is listed by path, sha256, size, save time, source URL and, where one exists, a public Wayback URL that anyone can open to re-check the quote. Each record also carries a short factual excerpt (`evidence_excerpt`). Included are only our own work products (URL lists, parsed rows, logs), Internet Archive CDX index metadata, and our compiled datasets. The datasets are shared for private academic review, as in the earlier packages, and are not cleared for analysis or redistribution.
