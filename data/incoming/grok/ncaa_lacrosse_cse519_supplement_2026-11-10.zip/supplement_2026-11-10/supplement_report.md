# Supplement report: recovered originals, odds evidence, permissions and references (2026-11-10)

**Scope.** This is file recovery, documentation and citation work only. Nothing was recollected, the 346-check audit was not re-run, no models were built, and no existing file or earlier zip was modified. All box times are ET.

## 1. Identifying the "six external originals" and the "five missing originals"
In `audit_package/validated_data_inventory.csv`, six files are referenced with `in_package=False`. They are listed by their `/workspace/final_package/` or `/workspace/deliverables/` path, and none was in the audit zip. They are:
1. `ncaa_lacrosse_games_2023.csv` (567 rows, sha256 62afa103…)
2. `ncaa_lacrosse_games_2024.csv` (570, c6a76875…)
3. `ncaa_lacrosse_game_index_2025.csv` (580, 71caef90…)
4. `ncaa_lacrosse_team_game_stats_2023_2025.csv` (3,428, 1afc8fad…)
5. `ncaa_lacrosse_player_stats_2023_2025.csv` (143,882, 0bfd6459…)
6. `ncaa_lacrosse_additional_odds_2023_2026.csv` (525, 8b8c58a0…)

Items 1–5 are the five game/stat originals. The pre-correction crosswalk (`odds_game_to_ncaa_game_crosswalk.csv`, 308 rows) also had only its corrected copy in the audit zip.

## 2. Priority 1: originals (all recovered)
- **What was recovered:** all six external originals, plus the crosswalk original and the duplicate-listing side file, are in `priority1_originals/recovered_originals/`. Each is a byte-identical copy. Each sha256 matches both `/workspace/final_package/` and `/workspace/lax_data/processed/`, and also matches the hash recorded earlier in `validated_data_inventory.csv`.
- **Where they came from (said plainly):** none of these is an externally downloaded file. Each is an intermediate built by our scripts:
  - `lax_data/scripts/04_build_datasets.py` built the games and stats files from raw NCAA JSON fetched on 2026-11-10:
    - data.ncaa.com scoreboards, 10:43–10:49 AM;
    - sdataprod.ncaa.com box scores and play-by-play, 10:47–11:30 AM.
  - The ESPN scoreboards fetched 10:43–10:49 AM supply the espn_* columns.
  - The CSVs were written at 11:42 AM and copied to final_package at 11:44 AM.
  - The raw inputs are listed by hash in `raw_ncaa_json_sha256.csv`: 4,223 files, 248 MB, not included. The fetch logs are included.
- **Change history:**
  - `original_vs_corrected_summary.csv` and `..._changed_cells.csv` compare each original with its corrected copy. Rows and row order are identical in all six pairs.
  - **Value changes (300 cells)** all correspond to the documented corrections:

    | Dataset | Value changes |
    |---|---|
    | Games 2023 | 12 |
    | Games 2024 | 6 |
    | Game index 2025 | 3 |
    | Team stats | 10 |
    | Player stats | 269 |
    | Crosswalk | 0 |

    The documented corrections behind them are the date fixes (03-01→03-02-2023, 2025-02-15→16, 2025-02-23→22, 2025-04-05→12), UMBC–Mount St. Mary's 2023 changing from not played to final 16–6, and 7 neutral-site flags.
  - **Format-only differences (5,966 cells)** are integer IDs written as floats in the corrected copies (e.g. `43978` → `43978.0`).
- **Not available to us:** your local 580-game 2025 CSV and your 72 team-season records were never on this box, so they were not recovered or compared.

## 3. Priority 2: odds evidence
- **Files:** 294 evidence files are on the box (`odds_evidence_inventory.csv`):
  - **36 included** in the zip: our own URL lists, parsed-row JSON and verification log (15), plus Internet Archive CDX index listings (21 non-empty).
  - **235 hash-only:** these are the third-party captures. By publisher:

    | Publisher | Files |
    |---|---|
    | Action Network | 90 |
    | Pinnacle | 51 |
    | Bet On Lacrosse | 34 |
    | DraftKings | 23 |
    | BetMGM | 16 |
    | ESPN | 12 |
    | Lacrosse All Stars | 8 |
    | LegalSportsBetting | 1 |

  - **23 are empty** (22 zero-byte CDX results and 1 empty URL list).
  - **101 files** directly support odds records.
- **Unchanged since the audit:** 277 of the 294 files appear in the audit package's earlier hash list (`raw_odds_evidence_sha256.txt`), and all 277 still match. The other 17 are helper lists and empty CDX files that list never covered. See `hash_crosscheck_vs_audit_package.json`.
- **Records:** `odds_evidence_to_record_map.csv` covers all 1,995 records: 1,470 original and 525 additional, including the 12 rejected.
  - **A saved evidence file exists for 1,995 of 1,995.** No record lacks saved evidence.
  - **Evidence file included in the zip: 0 of 1,995.** Every supporting file is restricted or uncertain, so each is given by sha256, path, source URL and an excerpt.
  - **Routes for independent re-checking:**
    - 878 records have a public Wayback capture URL anyone can open: DraftKings 412, BetMGM 292, Action Network 168, Bet On Lacrosse 6.
    - 1,117 rely on a live page that returned HTTP 200 on 2026-11-10 and has no archive copy. These can be re-checked today, but the pages may change. If they change before the files are authorized, these records become **unsupported for independent source verification**.
  - **Does the evidence print the value?**
    - 1,953 records: the value is printed in the saved evidence.
    - 39 records: the value is implied but not printed (all `requires_permission`, provisional).
    - 3 records: not printed (all rejected).
  - **Quote timestamps:**
    - 544 records have an original quote/capture timestamp (Wayback capture time).
    - 1,451 have none. For the 1,291 of those that have an article publication time, that time is recorded separately and is **not** treated as the quote time.
  - **Status:** 1,983 requires_permission and 12 rejected. By technical status: 1,887 verified, 96 provisional, 12 rejected.
  - **Grades:** A 702, B 1,207, C 86.
- **Source URL lists:** `source_url_lists/` holds:
  - the 93 first-pass URLs;
  - the audit-package URL list;
  - the live status on 2026-11-10;
  - the 93 evidence source URLs, each with its record IDs.

## 4. Priority 3: permissions
See `permissions_report.md` and `permissions_matrix.csv`.
- **Restricted:** Action Network, DraftKings, ESPN.
- **Uncertain:**
  - NCAA and the school sites;
  - BetMGM (the NJ/MA terms §26 bars reproduction, so it is treated as restricted for redistribution);
  - Bet On Lacrosse, Lacrosse All Stars and LegalSportsBetting (no terms exist);
  - the Internet Archive (permits research, but grants no rights in captured content).
- **Cleared by its terms:** The Odds API, which you have already contacted; no action is suggested.
- **Email drafts:** 7, not sent: Action Network, DraftKings, BetMGM, Bet On Lacrosse, Lacrosse All Stars, LegalSportsBetting and NCAA. A public contact address was found only for Lacrosse All Stars (editorial@laxallstars.com) and LegalSportsBetting (a contact form). The others list only legal-notice or DMCA addresses, which are noted as not licensing contacts, or none at all.

## 5. Priority 4: references
Eight references were verified through Crossref and doi.org, plus two alternates (`references.md`). Two are directly about lacrosse: Pfeifer 2016 (in the main list) and Plisk 1994 (an alternate). The rest are transferable methods.

## What was recovered
- All six external originals named in the audit inventory (games 2023, games 2024, game index 2025, team game stats, player stats, the 525 additional odds), plus the pre-correction crosswalk and the duplicate-listing file. Each is byte-identical with matching sha256.
- The raw-JSON fetch logs and build log, plus hashes of all 4,223 raw input files.
- A full inventory of 294 odds-evidence files with hashes. The 36 shareable ones (URL lists, parsed extractions, CDX index listings) are included.
- A record-by-record map of all 1,995 odds records to their evidence, URLs, timestamps and excerpts.
- A cell-level change history from originals to corrected copies.

## What is still missing
- **Your own files:** your local 580-game CSV and 72 team-season records. They were never on this box, so they are unavailable to us.
- **Earlier build outputs:** any output from runs of `04_build_datasets.py` or `07_odds_to_ncaa_crosswalk.py` before 11:42 AM, if those runs happened. Later runs would have overwritten them, and they cannot be recovered. The recovered files are the earliest persisted versions.
- **Third-party evidence files in the zip:** all 235 are withheld pending permission. They remain on the box with hashes.
- **Original quote timestamps:** absent for 1,451 odds records, because the sources never published them.
- **Current terms text:** the governing US BetMGM terms for non-account web visitors, and the current live Internet Archive terms (a 2020 copy was used).
- **Licensing contacts:** no address was found for Action Network, DraftKings, BetMGM, Bet On Lacrosse or the NCAA.

## Remaining limitations
- **No permission yet.** Nothing is cleared for analysis. All 1,983 non-rejected odds records stay quarantined, and the games and stats rest on NCAA terms that are uncertain.
- **Live-only evidence.** 1,117 odds records can be checked only against live pages, which are not permanent.
- **Partial independent corroboration of games.** Official school pages confirm 134 games in 2023, 115 in 2024 and 129 in 2025. The rest of the "verified" games rely on ESPN, which is restricted. This supplement did not add new corroboration.
- **Unresolved stat inconsistencies,** listed in `audit_package/games/revalidation_issues.csv`, carried over as provisional and not re-investigated here:
  - 14 player-goal sums that don't match the team total;
  - 3 incomplete box scores;
  - 11 cases of EMO goals > EMO opportunities, as published by NCAA;
  - 1 NCAA-vs-ESPN score conflict.
- **Format drift in the corrected copies.** They store integer IDs as floats. Compare on numeric value, or use the recovered originals for IDs.
- **Not legal advice.** The permission readings are interpretations, and the "unresolved" items need the source or a qualified reviewer to decide.
