# Proposal references (verified 2026-11-10)

**How each one was checked:** every DOI below was looked up through the Crossref REST API (`https://api.crossref.org/works/<DOI>`) on 2026-11-10 between 4:46 and 4:55 PM ET. The raw responses are saved in `crossref_records/`. Each DOI was also resolved through `https://doi.org/<DOI>` (HTTP 302 to the publisher page shown).

The authors, title, journal, volume, issue, pages and year in each citation are copied from the Crossref record. Page numbers are left out where Crossref has none. The relevance notes describe what each paper is about. They contain no numerical results.

The eight main references are listed first, then two verified alternates.

## Main references (8)

1. **Pfeifer, P. E. (2016).** The promise of pick-the-winners contests for producing crowd probability forecasts. *Theory and Decision*, 81(2), 255–278. https://doi.org/10.1007/s11238-015-9533-9 (resolves to link.springer.com)
   - **Relevance:** This paper builds probability forecasts from pick-the-winners contests, and its abstract says it tests them on 1,037 college lacrosse games against two benchmark sets of probabilities. It gives the project a published precedent for probability forecasting and benchmarking on college lacrosse.
   - **Type:** directly about lacrosse (college lacrosse games are its empirical data).

2. **Hvattum, L. M., & Arntzen, H. (2010).** Using ELO ratings for match result prediction in association football. *International Journal of Forecasting*, 26(3), 460–470. https://doi.org/10.1016/j.ijforecast.2009.10.002 (resolves to Elsevier, pii S0169207009001708)
   - **Relevance:** The paper turns Elo ratings into covariates for predicting match results and compares them with other predictors, including bookmaker odds. It is a template for building an Elo baseline for lacrosse teams and for comparing it with market odds.
   - **Type:** transferable method (association football).

3. **Glickman, M. E., & Stern, H. S. (1998).** A State-Space Model for National Football League Scores. *Journal of the American Statistical Association*, 93(441), 25–35. https://doi.org/10.1080/01621459.1998.10474084 (resolves to tandfonline.com)
   - **Relevance:** The paper models team strength as a quantity that changes over time, with a home-field effect, and predicts score differences. That suits a sport like lacrosse, where seasons are short and teams change between seasons. It also measures its predictions against the betting line, which matches our goal of checking models against sportsbook spreads.
   - **Type:** transferable method (American football, NFL).

4. **Brier, G. W. (1950).** Verification of forecasts expressed in terms of probability. *Monthly Weather Review*, 78(1), 1–3. https://doi.org/10.1175/1520-0493(1950)078<0001:VOFEIT>2.0.CO;2 (resolves to journals.ametsoc.org)
   - **Relevance:** This is the original definition of the Brier score, the mean squared error of probability forecasts, which we will use to score win probabilities from both the models and the de-vigged odds. Citing the original source fixes the metric's definition for the proposal.
   - **Type:** transferable method (weather forecasting).

5. **Gneiting, T., & Raftery, A. E. (2007).** Strictly Proper Scoring Rules, Prediction, and Estimation. *Journal of the American Statistical Association*, 102(477), 359–378. https://doi.org/10.1198/016214506000001437 (resolves to tandfonline.com)
   - **Relevance:** This is the standard theoretical reference on proper scoring rules, including the logarithmic and Brier scores, and on why they reward honest, calibrated probabilities. It justifies choosing log loss and the Brier score over raw accuracy when comparing lacrosse forecasts.
   - **Type:** transferable method (general statistics).

6. **Constantinou, A. C., & Fenton, N. E. (2012).** Solving the Problem of Inadequate Scoring Rules for Assessing Probabilistic Football Forecast Models. *Journal of Quantitative Analysis in Sports*, 8(1). https://doi.org/10.1515/1559-0410.1418 (resolves to degruyter.com)
   - **Relevance:** The paper argues for the ranked probability score when sports outcomes are ordered, and shows how some common scoring rules can mislead. This matters if we score ordered outcomes, such as margin-of-victory bins or against-the-spread categories, and not just win/loss.
   - **Type:** transferable method (association football).

7. **Štrumbelj, E. (2014).** On determining probability forecasts from betting odds. *International Journal of Forecasting*, 30(4), 934–943. https://doi.org/10.1016/j.ijforecast.2014.02.008 (resolves to Elsevier, pii S0169207014000533)
   - **Relevance:** The paper compares ways of turning bookmaker odds into outcome probabilities, which means removing the bookmaker margin, for example by simple normalization or Shin's model. We need exactly this step to make implied probabilities from the lacrosse moneylines comparable with model forecasts.
   - **Type:** transferable method (multiple sports).

8. **Levitt, S. D. (2004).** Why are Gambling Markets Organised so Differently from Financial Markets? *The Economic Journal*, 114(495), 223–246. https://doi.org/10.1111/j.1468-0297.2004.00207.x (resolves to academic.oup.com)
   - **Relevance:** Levitt argues from betting data that bookmakers do not simply set prices to balance the money on each side, so lines can depart from efficient prices. This frames our question of whether sportsbook lines for a niche market like NCAA lacrosse are efficient, and why line bias should be tested rather than assumed.
   - **Type:** transferable method (NFL betting).

## Verified alternates (optional)

9. **Kovalchik, S. A. (2016).** Searching for the GOAT of tennis win prediction. *Journal of Quantitative Analysis in Sports*, 12(3). https://doi.org/10.1515/jqas-2015-0059 (resolves to degruyter.com)
   - **Relevance:** Its Crossref abstract says it tests 11 published forecasting models, Elo-type ratings among them, on 2,395 ATP singles matches from the 2014 season. It is a model for a head-to-head evaluation design that reports both accuracy and calibration.
   - **Type:** transferable method (tennis).

10. **Plisk, S. S. (1994).** Regression Analyses of NCAA Division I Final Four Men's Lacrosse Competition. *Journal of Strength and Conditioning Research*, 8(1), 28–42. https://doi.org/10.1519/00124278-199402000-00005 (resolves to ovid.com)
    - **Relevance:** This early study uses regression on NCAA Division I men's Final Four games to find which game statistics are associated with winning. It is useful background for choosing team-stat features such as saves and ground balls, though it is descriptive rather than predictive.
    - **Type:** directly about lacrosse.

## Checked and not used
- Crossref title searches for "lacrosse", run 2026-11-10, found no other peer-reviewed lacrosse prediction or betting papers. "Here's the Scoop: Ground Balls Win Lacrosse Games" (Sommers et al., Middlebury College) appears in web search only as a RePEc preprint with no DOI, so it is not cited.
- All eight suggested candidate papers were confirmed through Crossref and doi.org, and none was dropped. Kovalchik is listed as an alternate only to keep the main list to eight.
