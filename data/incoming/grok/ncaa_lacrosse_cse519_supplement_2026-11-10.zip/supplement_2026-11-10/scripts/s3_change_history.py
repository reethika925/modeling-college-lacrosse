"""Small cell-level diff between recovered originals and the corrected copies in the audit package (lets reviewers check change history)."""
import pandas as pd, csv
W = "/workspace"; S = f"{W}/supplement_2026-11-10/priority1_originals"
pairs = [("ncaa_lacrosse_games_2023.csv", "ncaa_lacrosse_games_2023_corrected.csv", ["game_id"]),
         ("ncaa_lacrosse_games_2024.csv", "ncaa_lacrosse_games_2024_corrected.csv", ["game_id"]),
         ("ncaa_lacrosse_game_index_2025.csv", "ncaa_lacrosse_game_index_2025_corrected.csv", ["game_id"]),
         ("ncaa_lacrosse_team_game_stats_2023_2025.csv", "ncaa_lacrosse_team_game_stats_2023_2025_corrected.csv", None),
         ("ncaa_lacrosse_player_stats_2023_2025.csv", "ncaa_lacrosse_player_stats_2023_2025_corrected.csv", None),
         ("odds_game_to_ncaa_game_crosswalk.csv", "odds_game_to_ncaa_game_crosswalk_corrected.csv", None)]
summ, cells = [], []
for o, c, key in pairs:
    a = pd.read_csv(f"{S}/recovered_originals/{o}", dtype=str, keep_default_na=False)
    b = pd.read_csv(f"{W}/audit_package/corrected/{c}", dtype=str, keep_default_na=False)
    shared = [x for x in a.columns if x in b.columns]; added = [x for x in b.columns if x not in a.columns]
    same_order = len(a) == len(b) and (key is None or (a[key].values == b[key].values).all())
    n = 0
    if same_order:
        for col in shared:
            diff = a[col].values != b[col].values
            for i in diff.nonzero()[0]:
                ov, cv = a.at[i, col], b.at[i, col]
                try: fmt = ov != "" and cv != "" and float(ov) == float(cv)
                except ValueError: fmt = False
                n += 0 if fmt else 1
                cells.append(dict(dataset=o, row_index=int(i), key="|".join(a.loc[i, key]) if key else "", column=col, original_value=ov, corrected_value=cv,
                                  change_type="format_only (integer id re-serialised as float in corrected copy; same value)" if fmt else "value_change"))
    summ.append(dict(original=o, corrected=f"audit_package/corrected/{c}", rows_original=len(a), rows_corrected=len(b),
        row_order_identical=same_order, shared_columns=len(shared), columns_added_in_corrected=";".join(added),
        columns_dropped_in_corrected=";".join(x for x in a.columns if x not in b.columns), value_changes_in_shared_columns=n if same_order else "not compared (row order differs)", format_only_changes=sum(1 for x in cells if x["dataset"] == o and x["change_type"].startswith("format"))))
pd.DataFrame(summ).to_csv(f"{S}/original_vs_corrected_summary.csv", index=False)
pd.DataFrame(cells).to_csv(f"{S}/original_vs_corrected_changed_cells.csv", index=False)
print(pd.DataFrame(summ).to_string()); print(len(cells))
