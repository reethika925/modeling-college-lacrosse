"""Priority 2: inventory saved odds evidence, map all 1,995 odds records to evidence (read-only on sources)."""
import csv, hashlib, os, re, json, glob, shutil, datetime as dt, collections as C
import pandas as pd
W = "/workspace"; S = f"{W}/supplement_2026-11-10/priority2_odds_evidence"
os.makedirs(f"{S}/included_metadata", exist_ok=True)
def sha(p): return hashlib.sha256(open(p, "rb").read()).hexdigest()
def mt(p): return dt.datetime.fromtimestamp(os.path.getmtime(p)).strftime("%Y-%m-%d %H:%M:%S ET")
pa = pd.read_csv(f"{W}/audit_package/odds_provenance_audit.csv", dtype=str)
# url maps from our own lists
urlmap = {}
for l in open(f"{W}/wb/dk_snaps.txt"):
    ts, u = l.split()[:2]; urlmap[f"wb/dk_{ts}.html"] = (u, ts)
for l in open(f"{W}/an/map.txt"):
    a, u = l.split()[:2]; urlmap[f"an/{a}"] = (u, "")
for l in open(f"{W}/deliverables/raw_new/mgm/map.txt"):
    ts, u = l.split()[:2]; urlmap[f"deliverables/raw_new/mgm/mgm_{ts}.html"] = (u, ts)
for k, v in json.load(open(f"{W}/an_wb/verify.json")).items():
    for p in glob.glob(f"{W}/an_wb/{v['ts']}_*.html"): urlmap[p.replace(W + "/", "")] = (v.get("orig", k), v["ts"])
rec_by_file = C.defaultdict(list)
for _, r in pa.iterrows(): rec_by_file[r.evidence_file].append(r)
def classify(rel):
    b = os.path.basename(rel)
    if rel.startswith("wb/dk_") or "dknash" in rel or "cdx_dk" in b and False: return "DraftKings (via Internet Archive)", "restricted"
    if rel.startswith("an/") or rel.startswith("an_wb/"): return "Action Network" + (" (via Internet Archive)" if rel.startswith("an_wb/") else " (live)"), "restricted"
    if "/mgm/" in rel or b.startswith("mgm_"): return "BetMGM (via Internet Archive)", "uncertain"
    if rel.startswith("bol/") or "/bol_wb/" in rel: return "Bet On Lacrosse" + (" (via Internet Archive)" if "bol_wb" in rel else " (live)"), "uncertain"
    if "/las/" in rel: return "Lacrosse All Stars (live)", "uncertain"
    if "lsb" in rel: return "LegalSportsBetting (live)", "uncertain"
    if "/espn" in rel: return "ESPN", "restricted"
    if "/pin/" in rel: return "Pinnacle (via Internet Archive)", "not reviewed - treat as restricted"
    return "", ""
OWN = {"dk_rows.json", "an_rows.json", "bol_rows.json", "mgm_rows.json", "las_records.json", "dk_snaps.txt", "map.txt", "urls.txt",
       "an_urls.txt", "bol_urls.txt", "all.txt", "verify.json", "idx.txt", "lax.txt"}
files = []
for d in ["wb", "an", "an_wb", "bol", "lsb", "cdx", "espn", "deliverables/raw_new"]:
    files += [p for p in glob.glob(f"{W}/{d}/**/*", recursive=True) if os.path.isfile(p)]
files += [f"{W}/cdx_dk_leagues.txt", f"{W}/cdx_dk_event.txt"]
inv = []
for p in sorted(files):
    rel = p.replace(W + "/", ""); b = os.path.basename(rel); recs = rec_by_file.get(rel, [])
    pub, perm = classify(rel)
    url, ts = urlmap.get(rel, ("", ""))
    if recs:
        url = url or recs[0].source_url
        m = re.search(r"/web/(\d{14})", str(recs[0].archive_url)); ts = ts or (m.group(1) if m else "")
    if not ts:
        m = re.search(r"(\d{14})", b); ts = m.group(1) if m else ""
    if rel.startswith("bol/") and b.endswith(".html") and not url: url = f"https://betonlacrosse.com/{b[:-5]}/"
    if "/las/" in rel and b.endswith(".html") and not url: url = f"https://laxallstars.com/articles/{b[:-5]}"
    if "cdx" in b or rel.startswith("cdx/"):
        kind, pub, perm = "Internet Archive CDX index listing (capture URL/timestamp/status metadata)", "Internet Archive (CDX API)", "uncertain (index metadata, no captured page content)"
        url = url or "https://web.archive.org/cdx/search/cdx"
    elif b in OWN:
        kind, perm = "our own URL list / parsed extraction / verification log", "own work product (contains only URLs and extracted facts)"
        pub = pub + " - derived" if pub else "own"
    elif b.endswith((".html", ".json")):
        kind = "saved third-party page / API capture"
    else:
        kind = "other"
    inc = ("yes" if kind.startswith(("Internet Archive CDX", "our own")) else "no (hash only)") if os.path.getsize(p) > 0 else "no (empty file, 0 bytes)"
    if b == "test.html": kind = "saved third-party page (test fetch, not used for records)"
    wbu = ""
    if ts and url and "web.archive.org" not in url and kind.startswith("saved"): wbu = f"https://web.archive.org/web/{ts}/{url}"
    if recs and str(recs[0].archive_url) not in ("nan", ""): wbu = recs[0].archive_url
    inv.append(dict(evidence_path=rel, evidence_type=kind, publisher=pub, permission_class=perm, source_url=url,
        wayback_timestamp_utc=ts if (ts and ("wb" in rel or "mgm" in rel or "dknash" in rel or "an_wb" in rel or "bol_wb" in rel or "pin" in rel or "espn/" in rel)) else "",
        public_archive_url=wbu, saved_on_box_et=mt(p), bytes=os.path.getsize(p), sha256=sha(p), odds_records_supported=len(recs),
        included_in_zip=inc, zip_path=("priority2_odds_evidence/included_metadata/" + rel) if inc == "yes" else ""))
    if inc == "yes":
        os.makedirs(os.path.dirname(f"{S}/included_metadata/{rel}"), exist_ok=True); shutil.copy2(p, f"{S}/included_metadata/{rel}")
pd.DataFrame(inv).to_csv(f"{S}/odds_evidence_inventory.csv", index=False)
invd = {r["evidence_path"]: r for r in inv}
# record map
out = []
for _, r in pa.iterrows():
    e = invd[r.evidence_file]
    qt = r.quote_capture_timestamp if str(r.quote_capture_timestamp) != "nan" else ""
    note = "" if qt else ("no quote timestamp in source; article published_at is NOT the quote time" if str(r.article_published_at) != "nan" else "no quote timestamp in source")
    arch = r.archive_url if str(r.archive_url) != "nan" else ""
    live = str(r.url_status)
    if arch: path = "public Wayback capture (re-fetchable by anyone)"
    elif live.startswith("live HTTP 200"): path = "live public page (HTTP 200 on 2026-11-10; content may change; no archive copy)"
    else: path = "none"
    vr = str(r.verified_in_raw)
    if path == "none": flag = "unsupported_for_independent_verification"
    elif vr == "True": flag = "supported (value printed in saved evidence; file withheld, hash + public URL given)"
    elif vr == "implied_not_printed": flag = "partially_supported (price implied, not printed in evidence)"
    else: flag = "not_supported_by_evidence_text (verified_in_raw=False)"
    out.append(dict(record_id=r.record_id, source_dataset=r.source_dataset, orig_record_id=r.orig_record_id, season=r.season, game_id=r.game_id,
        sportsbook=r.sportsbook, market=r.market, selection=r.selection, line=r.line, american_odds=r.american_odds,
        evidence_file=r.evidence_file, evidence_sha256=e["sha256"], evidence_in_zip=e["included_in_zip"], evidence_publisher=e["publisher"],
        source_url=r.source_url, archive_url=arch, original_quote_timestamp_utc=qt,
        archive_capture_timestamp_utc=r.archive_capture_timestamp if str(r.archive_capture_timestamp) != "nan" else "",
        article_published_at_utc=r.article_published_at if str(r.article_published_at) != "nan" else "", timestamp_note=note,
        evidence_excerpt=r.evidence_detail, verified_in_raw=vr, evidence_grade=r.grade_audited, technical_status=r.technical_status, status=r.status,
        permission_class=r.permission_class, independent_verification_path=path, evidence_support_flag=flag,
        saved_evidence_file_exists="yes" if os.path.exists(f"{W}/{r.evidence_file}") else "NO - unsupported_for_independent_verification"))
m = pd.DataFrame(out); m.to_csv(f"{S}/odds_evidence_to_record_map.csv", index=False)
I = pd.DataFrame(inv)
counts = dict(records=len(m), by_status=m.status.value_counts().to_dict(), by_technical_status=m.technical_status.value_counts().to_dict(),
    by_dataset_status={f"{a}|{b}": int(n) for (a, b), n in m.groupby(["source_dataset", "status"]).size().items()},
    by_publisher=m.evidence_publisher.value_counts().to_dict(), by_sportsbook=m.sportsbook.value_counts().to_dict(),
    by_grade=m.evidence_grade.value_counts().to_dict(), saved_evidence_file_exists=m.saved_evidence_file_exists.value_counts().to_dict(),
    evidence_in_zip=m.evidence_in_zip.value_counts().to_dict(), by_verification_path=m.independent_verification_path.value_counts().to_dict(),
    by_support_flag=m.evidence_support_flag.value_counts().to_dict(),
    support_flag_by_status={f"{a}|{b}": int(n) for (a, b), n in m.groupby(["status", "evidence_support_flag"]).size().items()},
    with_quote_timestamp=int((m.original_quote_timestamp_utc != "").sum()), without_quote_timestamp=int((m.original_quote_timestamp_utc == "").sum()),
    distinct_evidence_files_used=int(m.evidence_file.nunique()),
    evidence_inventory=dict(files=len(I), included=int((I.included_in_zip == "yes").sum()), hash_only=int((I.included_in_zip != "yes").sum()),
        by_type=I.evidence_type.value_counts().to_dict(), hash_only_by_publisher=I[I.included_in_zip != "yes"].publisher.value_counts().to_dict(),
        files_supporting_records=int((I.odds_records_supported > 0).sum())))
json.dump(counts, open(f"{S}/odds_evidence_counts.json", "w"), indent=1)
print(json.dumps(counts, indent=1))
