"""Write MANIFEST.csv for every file in the supplement (except MANIFEST itself); also cross-check evidence hashes vs the audit package's earlier hash list."""
import os, csv, hashlib, json
S = "/workspace/supplement_2026-11-10"
def sha(p): return hashlib.sha256(open(p, "rb").read()).hexdigest()
DESC = {"README.md": "package guide", "supplement_report.md": "findings; recovered / missing / limitations", "verify_supplement.py": "integrity check against MANIFEST.csv"}
def desc(r):
    if r in DESC: return DESC[r]
    for k, v in [("recovered_originals/", "recovered original (byte-identical copy)"), ("raw_fetch_logs/", "raw fetch / build log"), ("included_metadata/", "shareable odds evidence metadata (own lists / parsed rows / CDX index)"),
                 ("source_url_lists/", "source URL list"), ("terms_retrieved", "terms-of-service page saved 2026-11-10 4:51 PM ET"), ("crossref_records/", "Crossref API record used to verify a reference"), ("scripts/", "build script for this supplement")]:
        if k in r: return v
    return r.split("/")[-1]
# cross-check against earlier audit hash list
old = {}
for l in open("/workspace/audit_package/evidence/odds/raw_odds_evidence_sha256.txt"):
    if l.startswith("#") or not l.strip(): continue
    h, p = l.split(None, 1); old[p.strip()] = h
inv = list(csv.DictReader(open(f"{S}/priority2_odds_evidence/odds_evidence_inventory.csv")))
cmp = dict(in_old_list=0, match=0, mismatch=[], not_in_old_list=0)
for r in inv:
    if r["evidence_path"] in old:
        cmp["in_old_list"] += 1
        if old[r["evidence_path"]] == r["sha256"]: cmp["match"] += 1
        else: cmp["mismatch"].append(r["evidence_path"])
    else: cmp["not_in_old_list"] += 1
json.dump(cmp, open(f"{S}/priority2_odds_evidence/hash_crosscheck_vs_audit_package.json", "w"), indent=1)
print("crosscheck", {k: (v if not isinstance(v, list) else len(v)) for k, v in cmp.items()})
rows = []
for d, _, fs in os.walk(S):
    for f in fs:
        p = os.path.join(d, f); r = os.path.relpath(p, S)
        if r == "MANIFEST.csv" or "__pycache__" in r: continue
        n = ""
        if f.endswith(".csv"):
            with open(p, newline="") as fh: n = sum(1 for _ in csv.reader(fh)) - 1
        rows.append(dict(path=r, bytes=os.path.getsize(p), rows=n, sha256=sha(p), description=desc(r)))
rows.sort(key=lambda x: x["path"])
with open(f"{S}/MANIFEST.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=["path", "bytes", "rows", "sha256", "description"]); w.writeheader(); w.writerows(rows)
print(len(rows), "files in manifest")
