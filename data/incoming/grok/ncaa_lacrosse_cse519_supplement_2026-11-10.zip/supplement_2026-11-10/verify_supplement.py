"""Integrity check: every MANIFEST.csv entry exists with the recorded sha256, bytes and CSV row count; no unlisted files. Run from this folder."""
import csv, hashlib, os, sys
here = os.path.dirname(os.path.abspath(__file__)); bad = 0
listed = set()
for r in csv.DictReader(open(os.path.join(here, "MANIFEST.csv"))):
    p = os.path.join(here, r["path"]); listed.add(r["path"])
    if not os.path.exists(p): print("MISSING", r["path"]); bad += 1; continue
    if hashlib.sha256(open(p, "rb").read()).hexdigest() != r["sha256"]: print("SHA MISMATCH", r["path"]); bad += 1
    if os.path.getsize(p) != int(r["bytes"]): print("SIZE MISMATCH", r["path"]); bad += 1
    if r["rows"] != "":
        with open(p, newline="") as fh: n = sum(1 for _ in csv.reader(fh)) - 1
        if n != int(r["rows"]): print("ROW MISMATCH", r["path"], n, r["rows"]); bad += 1
for d, _, fs in os.walk(here):
    for f in fs:
        rel = os.path.relpath(os.path.join(d, f), here)
        if rel != "MANIFEST.csv" and "__pycache__" not in rel and rel not in listed: print("UNLISTED", rel); bad += 1
print(f"{len(listed)} files checked, {bad} problems"); sys.exit(1 if bad else 0)
